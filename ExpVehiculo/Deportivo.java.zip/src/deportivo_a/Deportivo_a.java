package deportivo_a;
/*@author juannicolas*/
public class Deportivo_a {

    public static void main(String[] args) {
    
    }
    
}
